# Calcu Telegram Bot

Bu oddiy hisob-kitob va valyuta kurslarini ko‘rsatuvchi Telegram bot.

## Ishga tushirish (Render.com uchun):

- **Start command**: `python bot.py`
- **Build command**: `pip install -r requirements.txt`

Token kod bot.py faylida yozilgan (xavfsiz holatda .env faylga o‘tkazish tavsiya etiladi).