import telebot
from telebot import types
import requests

TOKEN = "7725000883:AAEDUIesH7VW8p52rYvo6YuMJkr7m9YhUoE"
bot = telebot.TeleBot(TOKEN)

# Valyuta kursini olish (USD, EUR dan UZS)
def get_exchange_rate(currency_code):
    try:
        url = f"https://cbu.uz/uz/arkhiv-kursov-valyut/json/{currency_code}/"
        response = requests.get(url)
        data = response.json()
        return float(data[0]['Rate'])
    except:
        return None

# Start komandasi
@bot.message_handler(commands=['start'])
def welcome(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("➕ Oddiy hisob")
    btn2 = types.KeyboardButton("💱 Valyuta kursi")
    markup.add(btn1, btn2)
    bot.send_message(message.chat.id, "Xush kelibsiz! Men hisob-kitob botman.", reply_markup=markup)

# Matnli javoblar
@bot.message_handler(func=lambda message: True)
def handle_message(message):
    text = message.text.strip()
    
    if text == "➕ Oddiy hisob":
        bot.send_message(message.chat.id, "Iltimos, ifoda yuboring. Masalan: 5 + (3 * 2)")
    
    elif text == "💱 Valyuta kursi":
        rates = {
            "USD": get_exchange_rate("usd"),
            "EUR": get_exchange_rate("eur"),
            "RUB": get_exchange_rate("rub")
        }
        msg = "\n".join([f"{cur}: {rate} so'm" for cur, rate in rates.items() if rate])
        bot.send_message(message.chat.id, f"Bugungi kurslar:\n{msg}")
    
    else:
        try:
            result = eval(text)
            bot.send_message(message.chat.id, f"Natija: {result}")
        except:
            bot.send_message(message.chat.id, "Xatolik! Iltimos, to‘g‘ri matematik ifoda yuboring yoki tugmadan foydalaning.")

# Inline qidiruv
@bot.inline_handler(func=lambda query: True)
def inline_handler(query):
    try:
        result = eval(query.query)
        r = types.InlineQueryResultArticle(
            id='1',
            title=f"Natija: {result}",
            input_message_content=types.InputTextMessageContent(f"{query.query} = {result}")
        )
        bot.answer_inline_query(query.id, [r])
    except:
        pass

bot.infinity_polling()